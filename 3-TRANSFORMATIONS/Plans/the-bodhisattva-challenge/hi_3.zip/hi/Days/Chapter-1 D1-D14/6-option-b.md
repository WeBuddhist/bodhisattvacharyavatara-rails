---
day: 6
chapter: 1
verses: "1-15 to 1-16"
status: draft
translated_from: "en/Days/Chapter-1 D1-D14/6.md"
generation_note: "Regenerated with the english-plan-generator skill; verse grouping realigned to en/assets/schedule.md. Commentary from en-ai/Verses summaries; English verses from en-AI-generated-root-loden-sherab.md; Tibetan from bo-བློ་ལྡན་ཤེས་རབ།.md. Needs domain-specialist review before status: complete."
---

# Day 6 — Wanting to go is not the same as going

> **Notification**
> **Title:** Notice what you keep meaning to start
> **Detail:** There are two kinds of this mind: wishing, and setting out. Today, notice the gap.

## Opening

आज के दो श्लोक इस मन के दो रंग दिखाते हैं। एक है जागने की बस चाह रखना। और दूसरा है उस चाह को लेकर असल में कदम बढ़ा देना। शांतिदेव बड़ी आसान मिसाल देते हैं: सफ़र पर जाने का मन करना और उठकर सचमुच निकल जाना, ये दोनों एक जैसे नहीं। दोनों की अपनी अहमियत है, पर यह पहचानना काम आता है कि इस वक़्त आप कहाँ खड़े हैं।

## Renewing the Bodhisattva Vow

> **Mind Training** *(recite 3 times)*
>
> May all beings enjoy happiness and the causes of happiness.
> May all beings be free from suffering and the causes of suffering.
> May all beings never be separated from supreme happiness, free from suffering.
> May all beings rest in great equanimity, free from attachment and aversion to those near and far.
>
> **Refuge** *(recite 3 times)*
>
> Until reaching the heart of buddhahood,
> I take refuge in the Buddha,
> I take refuge in the dharma,
> And in the sangha of bodhisattvas.
>
> **Taking the Bodhisattva Vow** *(recite 3 times)*
>
> Just as the buddhas of the past gave rise to bodhicitta
> And engaged step by step in the training of the bodhisattvas,
> So I too, for the benefit of all beings, will give rise to bodhicitta
> And engage step by step in that same training.

## Today's Verses

> བྱང་ཆུབ་སེམས་དེ་མདོར་བསྡུས་ན། །
> རྣམ་པ་གཉིས་སུ་ཤེས་བྱ་སྟེ། །
> བྱང་ཆུབ་སྨོན་པའི་སེམས་དང་ནི། །
> བྱང་ཆུབ་འཇུག་པ་ཉིད་ཡིན་ནོ། །
>
> Briefly, the mind of enlightenment has two aspects: the aspiring mind of enlightenment, and the engaging mind of enlightenment.

> འགྲོ་བར་འདོད་དང་འགྲོ་བ་ཡི། །
> བྱེ་བྲག་ཇི་ལྟར་ཤེས་པ་ལྟར། །
> དེ་བཞིན་མཁས་པས་འདི་གཉིས་ཀྱི། །
> བྱེ་བྲག་རིམ་བཞིན་ཤེས་པར་བྱ། །
>
> Think of the difference between wishing to travel and actually traveling. In the same way, the wise should understand the difference between these two minds.

## From the Tradition

पंद्रहवीं सदी के शिक्षक **ग्यालत्सब जे** एक बारीक बात पकड़ते हैं जो आसानी से नज़र से चूक जाती है। दोनों मन हू-ब-हू एक ही चीज़ चाहते हैं, दोनों चाहते हैं कि औरों के भले के लिए जागें।

फ़र्क़ चाह का नहीं है। फ़र्क़ बस यह है कि इनमें से एक ने कदम उठा लिया है। एक सच्चे मन से चाहता है, मगर जहाँ का तहाँ रह जाता है। दूसरा भी उतने ही सच्चे मन से चाहता है, और चल पड़ता है।

## Aspiration and Dedication

> May the precious bodhicitta
> Arise in those who don't have it yet;
> And in those who already have it,
> May it not decline, but grow ever further.
>
> By the merit of practicing
> The Bodhicharyavatara today
> May all living beings come to engage
> In the conduct of the bodhisattvas.

## Today's Practice

कोई एक काम मन में लाइए जिसे करने की सोच आप अरसे से पाले हुए हैं। आज उसे कर डालने का दबाव ख़ुद पर मत डालिए। बस सच्चाई से ग़ौर कीजिए कि आख़िर किस चीज़ की वजह से आप शुरू करने के बजाय चाहते ही रह जाते हैं।
