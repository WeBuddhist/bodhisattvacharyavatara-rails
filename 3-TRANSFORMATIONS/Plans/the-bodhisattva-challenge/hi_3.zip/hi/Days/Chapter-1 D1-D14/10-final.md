---
day: 10
chapter: 1
verses: "1-26 to 1-28"
status: draft
translated_from: "en/Days/Chapter-1 D1-D14/10.md"
generation_note: "Regenerated with the english-plan-generator skill; verse grouping realigned to en/assets/schedule.md. Commentary from en-ai/Verses summaries; English verses from en-AI-generated-root-loden-sherab.md; Tibetan from bo-བློ་ལྡན་ཤེས་རབ།.md. Needs domain-specialist review before status: complete."
---

# Day 10 — We want to be happy, and run the other way

> **Notification**
> **Title:** Name what you were really reaching for
> **Detail:** We chase happiness and, confused, run from it. Today, name what you actually wanted.

## Opening

<!-- अंतिम हिंदी अनुवाद यहाँ पेस्ट करें / paste final Hindi here -->

## Renewing the Bodhisattva Vow

> **Mind Training** *(recite 3 times)*
>
> May all beings enjoy happiness and the causes of happiness.
> May all beings be free from suffering and the causes of suffering.
> May all beings never be separated from supreme happiness, free from suffering.
> May all beings rest in great equanimity, free from attachment and aversion to those near and far.
>
> **Refuge** *(recite 3 times)*
>
> Until reaching the heart of buddhahood,
> I take refuge in the Buddha,
> I take refuge in the dharma,
> And in the sangha of bodhisattvas.
>
> **Taking the Bodhisattva Vow** *(recite 3 times)*
>
> Just as the buddhas of the past gave rise to bodhicitta
> And engaged step by step in the training of the bodhisattvas,
> So I too, for the benefit of all beings, will give rise to bodhicitta
> And engage step by step in that same training.

## Today's Verses

> འགྲོ་བ་ཀུན་གྱི་དགའ་བའི་རྒྱུ། །
> སེམས་ཅན་སྡུག་བསྔལ་རྩིར་གྱུར་པ། །
> རིན་ཆེན་སེམས་ཀྱི་བསོད་ནམས་གང་། །
> དེ་ལ་ཇི་ལྟར་གཞལ་གྱིས་ལང་། །
>
> This jewel of the mind is the cause of joy for all wandering beings, and the medicine that cures their suffering. How can its immeasurable merit ever be measured?

> ཕན་པར་བསམས་པ་ཙམ་གྱིས་ཀྱང་། །
> སངས་རྒྱས་མཆོད་ལས་ཁྱད་འཕགས་ན། །
> སེམས་ཅན་མ་ལུས་ཐམས་ཅད་ཀྱི། །
> བདེ་དོན་བརྩོན་པ་སྨོས་ཅི་དགོས། །
>
> Merely wishing to benefit others is far superior to making offerings to the Buddhas. What need is there to speak of striving for the happiness of all sentient beings without exception?

> སྡུག་བསྔལ་འདོར་འདོད་སེམས་ཡོད་ཀྱང་། །
> སྡུག་བསྔལ་ཉིད་ལ་མངོན་པར་རྒྱུག །
> བདེ་བ་འདོད་ཀྱང་གཏི་མུག་པས། །
> རང་གི་བདེ་བ་དགྲ་ལྟར་འཇོམས། །
>
> Although beings wish to abandon suffering, they run directly into suffering itself. Although they desire happiness, out of ignorance they destroy their own happiness like an enemy.

## From the Tradition

<!-- अंतिम हिंदी अनुवाद यहाँ पेस्ट करें / paste final Hindi here -->

## Aspiration and Dedication

> May the precious bodhicitta
> Arise in those who don't have it yet;
> And in those who already have it,
> May it not decline, but grow ever further.
>
> By the merit of practicing
> The Bodhicharyavatara today
> May all living beings come to engage
> In the conduct of the bodhisattvas.

## Today's Practice

<!-- अंतिम हिंदी अनुवाद यहाँ पेस्ट करें / paste final Hindi here -->
